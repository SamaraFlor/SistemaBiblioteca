package br.com.nava1.inicializacao;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import br.com.nava1.entity.Aluno;
import br.com.nava1.entity.AlunoDisciplina;
import br.com.nava1.entity.Avaliacao;
import br.com.nava1.entity.Disciplina;
import br.com.nava1.entity.Turma;
import br.com.nava1.repository.AlunoRepository;
import br.com.nava1.repository.DisciplinaRepository;

import br.com.nava1.service.AlunoService;
import br.com.nava1.service.AvaliacaoService;
import br.com.nava1.service.DisciplinaService;
import br.com.nava1.service.TurmaService;

@Component
public class init implements ApplicationListener<ContextRefreshedEvent> {

	@Autowired
	AlunoRepository alunoRepository;

	@Autowired
	AlunoService alunoService;

	@Autowired
	TurmaService turmaService;

	@Autowired
	DisciplinaRepository disciplinaRepository;

	@Autowired
	DisciplinaService disciplinaService;

	@Autowired
	AvaliacaoService avaliacaoService;

	public void onApplicationEvent(ContextRefreshedEvent event) {

		Aluno aluno1 = new Aluno();
		aluno1.setNome("Helena");

		Aluno aluno2 = new Aluno();
		aluno2.setNome("Maria");

		Aluno aluno3 = new Aluno();
		aluno3.setNome("João");

		alunoRepository.saveAll(Arrays.asList(aluno1, aluno2, aluno3));

		Disciplina java = new Disciplina();
		java.setNome("java");

		disciplinaService.salvar(java);

		Disciplina java2 = new Disciplina();
		java2.setNome("Java 2 ");

		disciplinaService.salvar(java2);

		Disciplina arquitetura = new Disciplina();
		arquitetura.setNome("arquitetura ");

		disciplinaService.salvar(arquitetura);

		Turma ads = new Turma();
		ads.setNome("ads");

		turmaService.salvar(ads);

		Turma rede = new Turma();
		rede.setNome("Rede");

		turmaService.salvar(rede);

		aluno1.setTurma(ads);
		aluno2.setTurma(rede);
		aluno3.setTurma(ads);

		aluno1.setDisciplinas(Arrays.asList(java, arquitetura, java2));
		aluno2.setDisciplinas(Arrays.asList(java));
		aluno3.setDisciplinas(Arrays.asList(java, arquitetura));

		alunoRepository.save(aluno1);
		alunoRepository.save(aluno2);
		alunoRepository.save(aluno3);

		Avaliacao avaliacao = new Avaliacao();

		AlunoDisciplina alunoDisciplina = new AlunoDisciplina();
		alunoDisciplina.setAluno(aluno1);
		alunoDisciplina.setDisciplina(arquitetura);

		avaliacao.setAlunoDisciplina(alunoDisciplina);
		avaliacao.setConceitos("A");
		avaliacaoService.save(avaliacao);

		AlunoDisciplina joaoJava = new AlunoDisciplina();
		joaoJava.setAluno(aluno2);
		joaoJava.setDisciplina(java);
		Avaliacao avaliacaoJoaoJava = new Avaliacao();
		avaliacaoJoaoJava.setAlunoDisciplina(joaoJava);
		avaliacaoJoaoJava.setConceitos("B");

		avaliacaoService.save(avaliacaoJoaoJava);

		Avaliacao aval = avaliacaoService.buscarNotaAlunoDisciplina(alunoDisciplina);
		System.out.println("aluno:     " + aval.getAlunoDisciplina().getAluno().getNome() + "     avaliação:  "
				+ aval.getConceitos());
		System.out.println("disciplina:  " + aval.getAlunoDisciplina().getDisciplina().getNome());
	}

}
