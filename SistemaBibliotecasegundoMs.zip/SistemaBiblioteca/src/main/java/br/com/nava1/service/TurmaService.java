package br.com.nava1.service;

import java.util.List;

import java.util.Optional;

import org.hibernate.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import br.com.nava1.entity.Turma;
import br.com.nava1.repository.TurmaRepository;

@Service
public class TurmaService {
	
	
    @Autowired
    TurmaRepository repo;
    
    
	public List<Turma> listaTodasTurmas(){
		return repo.findAll();
	}
	
	public Page<Turma> buscaPorPaginacao(int pagina,int linhasPorPagina,String direcao,String orderBy){
		PageRequest pageRequest = PageRequest.of(pagina, linhasPorPagina, Direction.valueOf(direcao), orderBy);
	     return new PageImpl<>(repo.findAll(),pageRequest,linhasPorPagina);
	}
	
	public Turma salvar(Turma turma) {
		return repo.save(turma);
	}
	
	public Turma buscaPorId(Integer id)throws ObjectNotFoundException {
    Optional<Turma> turma = repo.findById(id);
    return turma.orElseThrow(()-> new ObjectNotFoundException( null,"turma não encontrada"));
    }

	public void excluir (Integer id ) {
		repo.deleteById(id);
	}
	
	public Turma Alterar(Turma objTurma) {
		Turma turma = buscaPorId(objTurma.getId());
	     turma.setNome(objTurma.getNome());
	     return salvar(turma);
	} 
	
	
}