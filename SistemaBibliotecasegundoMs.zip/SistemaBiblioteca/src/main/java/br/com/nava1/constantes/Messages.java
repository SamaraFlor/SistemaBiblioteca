package br.com.nava1.constantes;

public class Messages {
	
	public static final String SWAGGER_GET_ALL = "retorno de todos os Registros";
	
	public static final String SWAGGER_INSERE = "inseri um novo Registro Registros";
	
	public static final String SWAGGER_GET= "Retorna um Registro pelo Id";
	
	public static final String SWAGGER_TAG_TURMA_ENDPOINT = "Turma";
	
	public static final String SWAGGER_TAG_FILE_ENDPOINT = "Arquivos";
	
	public static final String SWAGGER_UPDATE= "Atualiza um Registro pelo Id";
	
	public static final String SWAGGER_DELETE= "Remove um Registro pelo Id";
	
	public static final String SWAGGER_TAG_ALUNO_ENDPOINT = "Aluno";

	public static final String SWAGGER_TAG_DISCIPLINA_ENDPOINT = "Disciplina";
	
	public static final String SWAGGER_TAG_AVALIACAO_ENDPOINT = "Avaliação";
	
	public static final String SWAGGER_TAG_PAGINAS = "Paginas";
}
