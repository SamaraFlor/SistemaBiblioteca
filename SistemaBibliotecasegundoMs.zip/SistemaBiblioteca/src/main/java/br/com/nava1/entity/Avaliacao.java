package br.com.nava1.entity;

import java.io.Serializable;


import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table (name = "avaliacoes")
public class Avaliacao implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1087985365096629786L;

	@EmbeddedId
	private AlunoDisciplina alunoDisciplina;
	
	private String conceitos;

	public AlunoDisciplina getAlunoDisciplina() {
		return alunoDisciplina;
	}

	public void setAlunoDisciplina(AlunoDisciplina alunoDisciplina) {
		this.alunoDisciplina = alunoDisciplina;
	}

	public String getConceitos() {
		return conceitos;
	}

	public void setConceitos(String conceitos) {
		this.conceitos = conceitos;
	}
	
}
