package br.com.nava1.service;

import java.util.List;
import java.util.Optional;
import org.hibernate.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.com.nava1.entity.Disciplina;
import br.com.nava1.repository.DisciplinaRepository;

@Service
public class DisciplinaService {

	@Autowired
	private DisciplinaRepository disciplinaRepository;

	public List<Disciplina> listaTodasDisciplinas() {
		return disciplinaRepository.findAll();
	}

	public Disciplina buscaPorID(Integer id) throws ObjectNotFoundException {
		Optional<Disciplina> disc = disciplinaRepository.findById(id);
		return disc.orElseThrow(() -> new ObjectNotFoundException(null, "turma não encontrada"));
	}

	public Disciplina salvar(Disciplina disciplina) {
		return disciplinaRepository.save(disciplina);
	}

	public void excluir(Integer id) {
		disciplinaRepository.deleteById(id);
	}

	public Disciplina Alterar(Disciplina objDisciplina) {
		Disciplina disciplina = buscaPorID(objDisciplina.getId());
		disciplina.setNome(objDisciplina.getNome());
		return salvar(disciplina);
	}

}
