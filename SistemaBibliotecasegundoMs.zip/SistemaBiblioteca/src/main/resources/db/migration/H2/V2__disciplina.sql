insert into Disciplina (nome,id) values ('Logica', 5);


insert into Aluno (nome,id) values ('Larissa', 5);


